.. _contributors:

Contributors
============

Maintained and authored by:
---------------------------
Lucas Ou-Yang -- http://codelucas.com, lucasyangpersonal@gmail.com

Thanks to the following contributors:
-------------------------------------
https://github.com/codelucas/newspaper/graphs/contributors

Newspaper relied on some code of a few other open source projects:
------------------------------------------------------------------
Thanks to all who have contributed to python-goose.
You can find the contributors list here:
https://github.com/grangier/python-goose/graphs/contributors

Thanks to all who have contributed to PyTeaser.
You can find the contributors list here:
https://github.com/xiaoxu193/PyTeaser/graphs/contributors

Thanks to all who have contributed to gravity-goose.
You can find the contributors list here:
https://github.com/GravityLabs/goose/graphs/contributors

Thanks to all who have contributed to jieba.
You can find the contributors list here:
https://github.com/fxsjy/jieba/graphs/contributors

Thanks to all who have contributed to nltk.
You can find the contributors list here:
https://github.com/nltk/nltk/graphs/contributors

Thanks to all who have contributed to lxml.
You can find the contributors list here:
http://lxml.de/credits.html

Thanks to all who have contributed to requests.
You can find the contributors list here:
https://github.com/kennethreitz/requests/graphs/contributors

