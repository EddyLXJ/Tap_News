Maintained and authored by:
---------------------------
Lucas Ou-Yang -- lucasyangpersonal@gmail.com

Thanks to the following contributors:
-------------------------------------
https://github.com/codelucas/newspaper/graphs/contributors

Newspaper relied on some code of a few other open source projects:
------------------------------------------------------------------
Thanks to all who have contributed to python-goose.
You can find the contributors list here:
https://github.com/grangier/python-goose/graphs/contributors

Thanks to all who have contributed to PyTeaser.
You can find the contributors list here:
https://github.com/xiaoxu193/PyTeaser/graphs/contributors

Thanks to all who have contributed to gravity-goose.
You can find the contributors list here:
https://github.com/GravityLabs/goose/graphs/contributors

Thanks to all who have contributed to python-jieba.
You can find the contributors list here:
https://github.com/fxsjy/jieba/graphs/contributors
